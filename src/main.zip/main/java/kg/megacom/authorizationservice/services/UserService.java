package kg.megacom.authorizationservice.services;

import kg.megacom.authorizationservice.models.Users;

public interface UserService extends BaseService<Users> {
}
