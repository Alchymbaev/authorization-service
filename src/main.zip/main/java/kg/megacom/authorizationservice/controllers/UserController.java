package kg.megacom.authorizationservice.controllers;

import io.swagger.annotations.Api;
import kg.megacom.authorizationservice.models.Account;
import kg.megacom.authorizationservice.models.Users;
import kg.megacom.authorizationservice.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "Пользователь")
@RestController
@RequestMapping("api/v1/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/save")
    Users save(@RequestBody Users users){
        return userService.save(users);
    }

    @GetMapping("/findById")
    Users findById(@RequestParam Long id){
        return userService.findById(id);
    }

    @GetMapping("/findAll")
    List<Users> findAll(){
        return userService.findAll();
    }

    @DeleteMapping("/delete")
    Users delete(@RequestParam Long id){
        return userService.delete(id);
    }

}
