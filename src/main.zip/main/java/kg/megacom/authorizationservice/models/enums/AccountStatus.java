package kg.megacom.authorizationservice.models.enums;

public enum AccountStatus {
    ACTIVE,
    BLOKED,
    DELETED
}
