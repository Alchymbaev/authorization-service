package kg.megacom.authorizationservice.services.impl;

import kg.megacom.authorizationservice.dao.AccountRep;
import kg.megacom.authorizationservice.models.Account;
import kg.megacom.authorizationservice.services.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountServiceImpl implements AccountService {

    @Autowired
    private AccountRep accountRep;


    @Override
    public Account save(Account account) {
        return accountRep.save(account);
    }

    @Override
    public Account findById(Long id) {
        return accountRep.findById(id).orElseThrow(() -> new RuntimeException("Account not found"));
    }

    @Override
    public Account delete(Long id) {
        Account account = findById(id);
        account.setActive(false);
        return save(account);
    }

    @Override
    public List<Account> findAll() {
        return accountRep.findAll();
    }


    @Override
    public Account login(String login, String password) {
        //Account account = accountRep.findbyLogin(login);
        return accountRep.findByLogin(login);
    }
}
