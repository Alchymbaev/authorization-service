package kg.megacom.authorizationservice.services;

import kg.megacom.authorizationservice.models.Account;

public interface AccountService extends BaseService<Account> {

    Account login(String login, String password);
}
