package kg.megacom.authorizationservice.services.impl;

import kg.megacom.authorizationservice.dao.UserRep;
import kg.megacom.authorizationservice.models.Users;
import kg.megacom.authorizationservice.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRep userRep;

    @Override
    public Users save(Users users) {
        return userRep.save(users);
    }

    @Override
    public Users findById(Long id) {
        return userRep.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
    }

    @Override
    public Users delete(Long id) {
        Users users = findById(id);
        users.setActive(false);
        return save(users);
    }

    @Override
    public List<Users> findAll() {
        return userRep.findAll();
    }
}
