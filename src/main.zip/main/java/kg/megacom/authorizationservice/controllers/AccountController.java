package kg.megacom.authorizationservice.controllers;

import io.swagger.annotations.Api;
import kg.megacom.authorizationservice.models.Account;
import kg.megacom.authorizationservice.services.AccountService;
import org.hibernate.tool.schema.ast.SqlScriptParserException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "Аккаунт")
@RestController
@RequestMapping("api/v1/account")
public class AccountController {

    @Autowired
    private AccountService accountService;

    @PostMapping("/save")
    Account save(@RequestBody Account account) {
        return accountService.save(account);
    }

    @GetMapping("/findById")
    Account findById(@RequestParam Long id){
        return accountService.findById(id);
    }

    @GetMapping("/findAll")
    List<Account> findAll(){
        return accountService.findAll();
    }

    @GetMapping("/findByLogin")
    Account findByLogin(@RequestParam String login, @RequestParam String password){
        return accountService.login(login, password);
    }

    @DeleteMapping("/delete")
    Account delete(@RequestParam Long id){
        return accountService.delete(id);
    }

}
